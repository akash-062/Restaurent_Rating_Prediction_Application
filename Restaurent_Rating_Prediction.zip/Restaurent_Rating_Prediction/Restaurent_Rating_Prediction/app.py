import numpy as np
import pandas as pd
from flask import Flask, request, render_template
import pickle

# Initialize Flask app
app = Flask(__name__)

# Load the trained model (Ensure the path is correct)
model_path = "C:/Users/chris/Downloads/FLASK-End-to-end-Zomato-Restaurant-Price-Prediction-and-Deployment-master/FLASK-End-to-end-Zomato-Restaurant-Price-Prediction-and-Deployment-master/model.pkl"
with open(model_path, "rb") as file:
    model = pickle.load(file)

# Define actual feature names used in model training
FEATURE_NAMES = [
    "online_order",
    "book_table",
    "votes",
    "location",
    "rest_type",
    "cuisines",
    "cost",  # Rename "approx_cost(for two people)" to "cost"
    "menu_item"
]



@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Extract form values
        form_values = list(request.form.values())

        # Convert input values to appropriate types
        features = []
        for val in form_values:
            try:
                features.append(float(val))  # Convert numeric values
            except ValueError:
                features.append(val.lower())  # Convert text inputs to lowercase
        
        # Convert to DataFrame with correct column names
        feature_names = ["online_order", "book_table", "votes", "location", "rest_type", "cuisines", "cost", "menu_item"]
        final_features = pd.DataFrame([features], columns=feature_names)

        # Debug: Print the input data
        print("Input Data for Prediction:")
        print(final_features)

        # Make prediction
        prediction = model.predict(final_features)
        output = round(prediction[0], 1)

        return render_template('index.html', prediction_text=f'Predicted Rating: {output}')
    
    except Exception as e:
        return render_template('index.html', prediction_text=f"Error: {str(e)}")

if __name__ == "__main__":
    app.run(debug=True)
